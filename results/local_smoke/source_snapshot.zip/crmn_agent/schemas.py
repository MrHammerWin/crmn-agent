from typing import Literal

from pydantic import BaseModel, ConfigDict, Field


class Schema(BaseModel):
    model_config = ConfigDict(extra="forbid")


class Fact(Schema):
    key: str
    value: str


class Anchor(Schema):
    key: str
    value: str
    evidence: str


class Grounding(Schema):
    facts: list[Anchor]


class Representation(Schema):
    summary: str
    facts: list[Fact]
    subgoals: list[str]
    action: str
    expected: list[str]
    value: float = Field(ge=0, le=1)


class Reconstruction(Schema):
    facts: list[Fact]


class Verdict(Schema):
    prediction: str
    status: Literal["supported", "contradicted", "unknown"]
    evidence: str


class Audit(Schema):
    verdicts: list[Verdict]


class Decision(Schema):
    reflection: str
    action: str

